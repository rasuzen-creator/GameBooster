package uz.rasuzen.gamebooster

import android.app.Activity
import android.app.ActivityManager
import android.app.AlertDialog
import android.app.NotificationManager
import android.content.Intent
import android.content.IntentFilter
import android.graphics.Color
import android.os.BatteryManager
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.provider.Settings
import android.view.ViewGroup
import android.widget.Button
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView
import android.widget.Toast

class MainActivity : Activity() {

    private lateinit var ramText: TextView
    private lateinit var tempText: TextView
    private lateinit var statusText: TextView
    private lateinit var gamesBox: LinearLayout
    private val handler = Handler(Looper.getMainLooper())
    private val prefs by lazy { getSharedPreferences("booster", MODE_PRIVATE) }

    private val ticker = object : Runnable {
        override fun run() {
            refreshStats()
            handler.postDelayed(this, 2000)
        }
    }

    private fun dp(v: Int) = (v * resources.displayMetrics.density).toInt()

    private fun text(size: Float, color: Int = Color.WHITE, bold: Boolean = false) =
        TextView(this).apply {
            textSize = size
            setTextColor(color)
            if (bold) setTypeface(typeface, android.graphics.Typeface.BOLD)
            setPadding(0, dp(6), 0, dp(6))
        }

    private fun btn(label: String, onClick: () -> Unit) = Button(this).apply {
        text = label
        isAllCaps = false
        textSize = 16f
        setOnClickListener { onClick() }
        layoutParams = LinearLayout.LayoutParams(
            ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT
        ).apply { topMargin = dp(8) }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        val col = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(20), dp(32), dp(20), dp(32))
        }
        col.addView(text(26f, Color.parseColor("#4ADE80"), true).apply { this.text = "🎮 Game Booster" })
        ramText = text(17f); col.addView(ramText)
        tempText = text(17f); col.addView(tempText)

        col.addView(btn("⚡ BOOST (fon ilovalarni tozalash)") { doBoost(null) })
        col.addView(btn("🔕 DND yoqish / o'chirish") { toggleDnd() })
        col.addView(btn("➕ O'yinlarni tanlash") { pickGames() })

        statusText = text(15f, Color.parseColor("#FACC15")); col.addView(statusText)
        col.addView(text(20f, Color.WHITE, true).apply { this.text = "O'yinlarim" })
        gamesBox = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        col.addView(gamesBox)

        setContentView(ScrollView(this).apply {
            setBackgroundColor(Color.parseColor("#0F1115"))
            addView(col)
        })
        renderGames()
    }

    override fun onResume() { super.onResume(); handler.post(ticker) }
    override fun onPause() { super.onPause(); handler.removeCallbacks(ticker) }

    private fun availMb(): Long {
        val am = getSystemService(ACTIVITY_SERVICE) as ActivityManager
        val mi = ActivityManager.MemoryInfo()
        am.getMemoryInfo(mi)
        return mi.availMem / 1048576
    }

    private fun refreshStats() {
        val am = getSystemService(ACTIVITY_SERVICE) as ActivityManager
        val mi = ActivityManager.MemoryInfo()
        am.getMemoryInfo(mi)
        ramText.text = "💾 RAM: bo'sh ${mi.availMem / 1048576} MB / ${mi.totalMem / 1048576} MB"

        val b = registerReceiver(null, IntentFilter(Intent.ACTION_BATTERY_CHANGED))
        val temp = (b?.getIntExtra(BatteryManager.EXTRA_TEMPERATURE, 0) ?: 0) / 10f
        val level = b?.getIntExtra(BatteryManager.EXTRA_LEVEL, 0) ?: 0
        tempText.text = "🌡️ Harorat: $temp °C   🔋 $level%"
    }

    /** Fon ilovalarni yopadi. keep — yopilmaydigan paket (o'yin). */
    private fun doBoost(keep: String?) {
        val before = availMb()
        val am = getSystemService(ACTIVITY_SERVICE) as ActivityManager
        val launcher = Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_LAUNCHER)
        val pkgs = packageManager.queryIntentActivities(launcher, 0)
            .map { it.activityInfo.packageName }
            .distinct()
            .filter { it != packageName && it != keep }
        pkgs.forEach { am.killBackgroundProcesses(it) }
        statusText.text = "⏳ Tozalanmoqda..."
        handler.postDelayed({
            val freed = (availMb() - before).coerceAtLeast(0)
            statusText.text = "✅ ${pkgs.size} ta ilova tekshirildi, ~$freed MB bo'shadi"
            refreshStats()
        }, 1200)
    }

    private fun setDnd(enable: Boolean): Boolean {
        val nm = getSystemService(NotificationManager::class.java)
        if (!nm.isNotificationPolicyAccessGranted) {
            Toast.makeText(this, "DND uchun ruxsat bering", Toast.LENGTH_LONG).show()
            startActivity(Intent(Settings.ACTION_NOTIFICATION_POLICY_ACCESS_SETTINGS))
            return false
        }
        nm.setInterruptionFilter(
            if (enable) NotificationManager.INTERRUPTION_FILTER_PRIORITY
            else NotificationManager.INTERRUPTION_FILTER_ALL
        )
        return true
    }

    private fun toggleDnd() {
        val nm = getSystemService(NotificationManager::class.java)
        val isOn = nm.currentInterruptionFilter != NotificationManager.INTERRUPTION_FILTER_ALL
        if (setDnd(!isOn)) {
            statusText.text = if (isOn) "🔔 DND o'chirildi" else "🔕 DND yoqildi"
        }
    }

    private fun savedGames(): Set<String> = prefs.getStringSet("games", emptySet()) ?: emptySet()

    private fun labelOf(pkg: String): String = try {
        packageManager.getApplicationLabel(packageManager.getApplicationInfo(pkg, 0)).toString()
    } catch (e: Exception) { pkg }

    private fun renderGames() {
        gamesBox.removeAllViews()
        val games = savedGames()
        if (games.isEmpty()) {
            gamesBox.addView(text(15f, Color.GRAY).apply {
                text = "Hali o'yin tanlanmagan. \"O'yinlarni tanlash\" tugmasini bosing."
            })
            return
        }
        games.sortedBy { labelOf(it) }.forEach { pkg ->
            gamesBox.addView(btn("▶ ${labelOf(pkg)}  (Boost + DND + O'yna)") { launchGame(pkg) })
        }
    }

    private fun pickGames() {
        val launcher = Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_LAUNCHER)
        val apps = packageManager.queryIntentActivities(launcher, 0)
            .map { it.activityInfo.packageName }
            .distinct()
            .filter { it != packageName }
            .sortedBy { labelOf(it).lowercase() }
        val names = apps.map { labelOf(it) }.toTypedArray()
        val saved = savedGames()
        val checked = BooleanArray(apps.size) { apps[it] in saved }

        AlertDialog.Builder(this)
            .setTitle("O'yinlarni tanlang")
            .setMultiChoiceItems(names, checked) { _, i, c -> checked[i] = c }
            .setPositiveButton("Saqlash") { _, _ ->
                val chosen = apps.filterIndexed { i, _ -> checked[i] }.toSet()
                prefs.edit().putStringSet("games", chosen).apply()
                renderGames()
            }
            .setNegativeButton("Bekor", null)
            .show()
    }

    private fun launchGame(pkg: String) {
        setDnd(true)
        doBoost(pkg)
        val i = packageManager.getLaunchIntentForPackage(pkg)
        if (i != null) startActivity(i)
        else Toast.makeText(this, "O'yin topilmadi", Toast.LENGTH_SHORT).show()
    }
}
