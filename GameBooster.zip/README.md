# Game Booster (Android, Kotlin)
MVP: RAM/harorat monitoring, fon ilovalarni tozalash, DND, o'yin ro'yxati (Boost + DND + ochish).
Build: `gradle assembleDebug` -> app/build/outputs/apk/debug/
